# -*- coding: utf-8 -*-
"""
Created on Sun Jul 12 12:03:54 2020

@author: HARI CHANDANA
"""
from collections import OrderedDict 

class LRU_Cache:

    def __init__(self, capacity):
        # Initialize class variables
        self.cache = OrderedDict()
        self.capacity = capacity
        pass

    def get(self, key):
        # Retrieve item from provided key. Return -1 if nonexistent. 
        if key in self.cache:
            self.cache.move_to_end(key)
            return self.cache[key]
        if self.capacity == 0:
            return "no capacity"
        if self.capacity < 0:
            return "capacity cannot be -ve!! kindly reinitialize the cache..."
        return -1
        pass

    def set(self, key, value):
        # Set the value if the key is not present in the cache. If the cache is at capacity remove the oldest item.
        self.cache[key] = value
        self.cache.move_to_end(key)
        if len(self.cache) > self.capacity and self.capacity!=0:
            self.cache.popitem(last = False)
        if self.capacity == 0:
            return "no capacity"
        pass

our_cache = LRU_Cache(5)

print("Test case 1:")
our_cache.set(1, 1)
our_cache.set(2, 2)
our_cache.set(3, 3)
our_cache.set(4, 4)


print(our_cache.get(1))       # returns 1
print(our_cache.get(2))    # returns 2
print(our_cache.get(9))      # returns -1 because 9 is not present in the cache

our_cache.set(5, 5) 
our_cache.set(6, 6)

print(our_cache.get(3))      # returns -1 because the cache reached it's capacity and 3 was the least recently used entry


print("\nTest case 2:")

next_cache = LRU_Cache(0) #null capacity
print(next_cache.get(1)) # returns no capacity

next_cache.set(1,2)
print(next_cache.get(2)) # returns no capacity

print("\nTest case 3:")

neg_cache = LRU_Cache(-3) #negative capacity

neg_cache.set(2,4)
print(neg_cache.get(4))  #returns a message

print("\nTest case 4:")

our_cache.set(4, 4)  #already existing in the cache
print(our_cache.get(4)) #returns the key

print("\nTest case 5:")

our_cache.set(7,7)
our_cache.set(8,8)
our_cache.set(9,9)
our_cache.set(10,10)

print(our_cache.get(8))
print(our_cache.get(12))


