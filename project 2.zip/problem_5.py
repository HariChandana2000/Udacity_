# -*- coding: utf-8 -*-
"""
Created on Wed Jul 15 10:10:58 2020

@author: HARI CHANDANA
"""


import hashlib
import time

class Block:

    def __init__(self, timestamp, data, previous_hash=0):
      self.timestamp = timestamp
      self.data = data
      self.previous_hash = previous_hash
      self.hash = self.calc_hash()
      
    def calc_hash(self):
        sha = hashlib.sha256()
        if type(self.data) == str:
            hash_str = self.data.encode('utf-8')
        else:
            hash_str = str(self.data).encode('utf-8')
        sha.update(hash_str)
        return sha.hexdigest()
    
    def __str__(self):
        return ('Timestamp: {}\nData: {}\nPrevious Hash: {}\nHash: {}\n'.format(self.timestamp, self.data, self.previous_hash, self.hash))

class Blockchain:

    def __init__(self):
        self.current_block = None

    def add_block(self, info):
        timestamp = time.gmtime()
        data = info
        previous_hash = self.current_block.hash if self.current_block else 0
        self.current_block = Block(timestamp, data, previous_hash)
        

blockchain = Blockchain()
blockchain.add_block("") #empty data
print(blockchain.current_block)

blockchain.add_block("hello, the number") #data in the form of text
print(blockchain.current_block)

blockchain.add_block("8976567809") # data in the form integer
print(blockchain.current_block)

blockchain.add_block("is my mobile number")
print(blockchain.current_block)


blockchain_2 = Blockchain()
blockchain.add_block(-23)  #negative number
print(blockchain.current_block)

blockchain_2.add_block("My name is Hari Chandana!! I've added enough number of test cases for this problem, also this is the 3 rd time I'm submitting") #text
print(blockchain_2.current_block)

blockchain_2.add_block("Kindly review this program with attention!!")
print(blockchain_2.current_block)

blockchain_2.add_block("Udacity is the best platform in the world !!")
print(blockchain_2.current_block)

blockchain_2.add_block(" ") #single space
print(blockchain_2.current_block)

blockchain_2.add_block("") #empty
print(blockchain_2.current_block)

blockchain_3 = Blockchain()
blockchain_3.add_block("\n") #escape character
print(blockchain_3.current_block)

blockchain_3.add_block(blockchain_2) # containing information about another blockchain
print(blockchain_3.current_block)

blockchain_3.add_block("\t") # tab space
print(blockchain_3.current_block)

blockchain_3.add_block(345.78) #float number
print(blockchain_3.current_block)

blockchain_3.add_block(2*3+5) #an expression
print(blockchain_3.current_block)