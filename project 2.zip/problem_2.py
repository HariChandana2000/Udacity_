# -*- coding: utf-8 -*-
"""
Created on Sun Jul 12 17:16:16 2020

@author: HARI CHANDANA
"""

import os

global files
files = []

def find_files(suffix, path):
    """
    Find all files beneath path with file name suffix.

    Note that a path may contain further subdirectories
    and those subdirectories may also contain further subdirectories.

    There are no limit to the depth of the subdirectories can be.

    Args:
      suffix(str): suffix if the file name to be found
      path(str): path of the file system

    Returns:
       a list of paths
    """
    files = []
    
    try:
        if suffix != "":
            for i in os.listdir(path):
                if os.path.isfile(path+"/"+i) and i.endswith(suffix):
                    files.append(path+"/"+i)
        else:
            for i in os.listdir(path):
                if os.path.isfile(path+"/"+i):
                    files.append(path+"/"+i)
                else:
                    files = files + find_files(suffix,path+"/"+i)
            return files
                
    except FileNotFoundError:
        return path+" is not found in the current directory.."    
        
    if files == []:
        return "there's no such file with "+suffix+" extension."

    return files


print(find_files(".c","./testdir"))  # .c files in the given directory
print(find_files(".c","./new_dir"))  # invalid directory
print(find_files(".py","./testdir")) # no such suffix in the path
print(find_files(".h","./testdir"))  
print(find_files(".c","./testdir/subdir3/subsubdir1"))
print(find_files("","./testdir"))   # all the files under ./testdir