I have used a max heap to sort the numbers. Then I popped off each number and alternated which output I appended to.

Time Complexity: O(nlog n)

Heapifying the array takes O(nlog n), popping every element takes O(nlog n), and creating the output takes O(n) resulting in O(nlog n).

Space Complexity: O(n)

The max heap creates a new array of size n.