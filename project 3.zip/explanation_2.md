The rotated array is able to be searched using a Binary Search Algorithm. 
It involves finding the pivot element and then splitting up the array into two sub arrays and implementing Binary search algorithm on these two sub arrays.

Time Complexity: O(log n)

Binary Search

Space Complexity: Is not constant as additional space is used

