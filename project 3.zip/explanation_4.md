The solution two this problem includes creating three separate lists for one's two's and three's and appending the elements from input list into the respectives lists and finally returning them together

Time complexity : O(n)

Space complexity : O(n) since three lists are used