# -*- coding: utf-8 -*-
"""
Created on Wed Jul 22 12:07:58 2020

@author: HARI CHANDANA
"""


from collections import defaultdict


class TrieNode:
    def __init__(self):
        self.children = defaultdict(TrieNode)
        self.isword = False

    def suffixes(self, suffix=''):
        suffixes = []
        for char, node in self.children.items():
            if node.isword:
                suffixes.append(suffix + char)
            if node.children:
                suffixes += node.suffixes(suffix + char)
        return suffixes


class Trie:
    def __init__(self):
        self.root = TrieNode()

    def insert(self, word):
        node = self.root
        for char in word:
            node = node.children[char]
        node.isword = True

    def exists(self, word):
        node = self.find(word)
        return node.isword if node else False

    def find(self, prefix):
        node = self.root
        for char in prefix:
            if char in node.children:
                node = node.children[char]
            else:
                return None
        return node



trie = Trie()

wordList = [
    "ant", "anthology", "antagonist", "antonym",
    "fun", "function", "factory",
    "trie", "trigger", "trigonometry", "tripod"
]


for word in wordList:
    trie.insert(word)

# finding whether the letter exists in Trie or not
print(type(trie.find("a")) is TrieNode)
print(trie.find("b") is None)

# exists
print(trie.exists("ant") is True)
print(trie.exists("tripod") is True)
print(trie.exists("anthony") is False)
print(trie.exists("bob") is False)


# suffixes
node = trie.find("a")
print(node.suffixes() == ["nt", "nthology", "ntagonist", "ntonym"])

node = trie.find("")
print(node.suffixes() == [
    "ant", "anthology", "antagonist", "antonym",
    "fun", "function", "factory",
    "trie", "trigger", "trigonometry", "tripod"
])

node = trie.find("facto")
print(node.suffixes() == ["ry"])

node = trie.find("factory")
print(node.suffixes() == [])

